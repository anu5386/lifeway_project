package com.example.demo.Controller;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.Iterator;

@RestController




    public class CountcharactersController {
        public static String countoutput = new String();


        public static void main(String[] args) {
            //Method: java.net.http.HTTPClient
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder().uri(URI.create("http://localhost:3000/")).build();
            client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                    .thenApply(HttpResponse::body)
                    .thenApply(CountcharactersController::parse)
                    .join();
        }
        public static String parse(String responseBody) {
            String readmsg= new String(responseBody);
            //System.out.println(responseBody);
            readmsg = "{\"\": "+readmsg+"}";
            HashMap<String, String> hashMap = new HashMap<String, String>();
            //JSONObject jobject=(JSONObject) readmsg;
            String arr = readmsg.toString();
            JSONObject jsonObj = new JSONObject(arr);
            Iterator it = jsonObj.keys();
            while (it.hasNext()) {
                hashMap.clear();
                JSONArray jsInner = (JSONArray) jsonObj.getJSONArray((String) it.next());
                for (int i=0;i<jsInner.length();i++) {
                    JSONObject jo = new JSONObject(jsInner.get(i).toString());
                    hashMap.put((String)jo.get("id"), (String)jo.get("message"));
                    String id = (String) jo.get("id");
                    String message = (String) jo.get("message");


                }
                JSONObject jsoninput =  new JSONObject(hashMap);
                JSONArray arrayinput = new JSONArray();
                int totalcount=0;
                arrayinput.put(jsoninput);
                String values = String.valueOf(hashMap.values()).strip();
                values=values.replace("[","");
                values=values.replace("]","");
                values=values.replace(" ","");
                String[] splitstr=values.split(",");
                for(int i=0;i<splitstr.length;i++) {
                    int count=splitstr[i].length();
                    totalcount=totalcount+count;

                    countoutput=String.valueOf(totalcount);

                    System.out.println(countoutput);

                }
            }

            //counting the number og characetrs code ends here*/
            return countoutput;

        }



        @RequestMapping("/countcharacters")
   public Countcharacters countcharacters(@RequestParam(value="0",defaultValue="0") String value) {
   return new Countcharacters(countoutput);

    /*
    @GetMapping("/database_connection")
    public database_connection database_connection(@RequestParam(value="0",defaultValue="0") String value) {
        return new database_connection(counter.incrementAndGet(),message);
        */

   }

}

