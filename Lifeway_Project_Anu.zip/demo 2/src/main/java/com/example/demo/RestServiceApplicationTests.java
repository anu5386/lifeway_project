package com.example.demo;

//import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
//import org.springframework.boot.test.context.SpringBootTest;


@SpringBootApplication
@EntityScan({"com.example.demo.service"})

public class RestServiceApplicationTests {

	public static void main(String[] args){
		SpringApplication.run(RestServiceApplicationTests.class,args);
	}

}
