package com.example.demo.Controller;

public class Countcharacters {

    private final String countoutput;

    public Countcharacters(String countoutput) {

        this.countoutput = countoutput;
    }


    public String countoutput() {

        return countoutput;
    }
}
